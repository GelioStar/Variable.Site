const fastify = require('fastify')({ logger: true });
const path = require('node:path');

const fastifyEnv = require('@fastify/env');
const fastifyStatic = require('@fastify/static');
const fastifyMySQL = require('@fastify/mysql');
const mainRoute = require(path.join(__dirname, 'routes', 'Route.Main.js'));
const shopRoute = require(path.join(__dirname, 'routes', 'Route.Shop.js'));

const schema = {
  type: 'object',
  required: ['PORT', 'DATABASE_HOST', 'DATABASE_USERNAME', 'DATABASE_PASSWORD', 'DATABASE_NAME'],
  properties: {
    PORT: {
      type: 'string',
      default: "3000"
    },
    DATABASE_HOST: {
      type: 'string',
      default: "localhost"
    },
    DATABASE_PORT: {
      type: 'string',
      default: "3306"
    },
    DATABASE_USERNAME: {
      type: 'string',
      default: "root"
    },
    DATABASE_PASSWORD: {
      type: 'string'
    },
    DATABASE_NAME: {
      type: 'string',
      default: "site"
    }
  }
};

fastify.register(fastifyEnv, {
  confKey: 'config',
  schema: schema,
  dotenv: true
});

// Подключение всех плагинов после загрузки переменных окружения
fastify.after(async () => {
  // Подключение MySQL
  fastify.register(fastifyMySQL, {
    host: fastify.config.DATABASE_HOST,
    port: fastify.config.DATABASE_PORT,
    user: fastify.config.DATABASE_USERNAME,
    password: fastify.config.DATABASE_PASSWORD,
    database: fastify.config.DATABASE_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  fastify.register(fastifyStatic, {
    root: path.join(__dirname, 'client'),
    prefix: '/',
  });

  fastify.register(mainRoute, { prefix: '/' });
  fastify.register(shopRoute, { prefix: '/shop' });
});

fastify.ready().then(() => {
  fastify.listen({ port: fastify.config.PORT }, (err, address) => {
    if (err) throw err
    console.log(`Server running at ${address}`);
  });
}).catch((err) => {
  console.error(err);
  process.exit(1);
});