// module.exports = {
//   getHome: async (request, reply) => {
//     const db = request.server.mysql;
//     try {
//       const [rows] = await db.query('SELECT * FROM mysql WHERE slug = ?', ['home']);
//       return rows.length > 0 ? rows[0] : { error: 'Not found' };
//     } catch (err) {
//       reply.code(500).send({ error: err.message });
//     }
//   },

//   getAbout: async (request, reply) => {
//     const db = request.server.mysql;
//     try {
//       const [rows] = await db.query('SELECT * FROM mysql WHERE slug = ?', ['about']);
//       return rows.length > 0 ? rows[0] : { error: 'Not found' };
//     } catch (err) {
//       reply.code(500).send({ error: err.message });
//     }
//   }
// };