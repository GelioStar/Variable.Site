module.exports = async function (fastify, opts) {
  fastify.get('/', async (request, reply) => {
    return reply.sendFile('pages/main/index.html');
  });
};